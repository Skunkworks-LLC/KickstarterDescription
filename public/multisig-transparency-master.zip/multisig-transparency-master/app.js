(
  function () {
    angular.module(
      'multiSigWeb',
      [
        'ui.bootstrap',
        'ngRoute',
        'ngclipboard'
      ]
    );
  }
)();
